// services/sleepService.js

const Sleep = require('../models/sleepModel');
const { DateTime } = require('luxon');

const sleepService = {
  getAllSleepData: function() {
    return Sleep.getAll().then(function(sleepData) {
      // Convert timestamps to IST using Luxon
      const sleepDataIST = sleepData.map(function(data) {
        return {
          ...data,
          startTime: convertToIST(data.startTime),
          endTime: convertToIST(data.endTime)
        };
      });
      return sleepDataIST;
    }).catch(function(error) {
      console.error('Error fetching sleep data:', error);
      throw new Error('Error fetching sleep data');
    });
  },

  addSleepData: function(startTime, endTime, duration) {
    return Sleep.create(startTime, endTime, duration).catch(function(error) {
      console.error('Error adding sleep data:', error);
      throw new Error('Error adding sleep data');
    });
  },

  deleteSleepDataById: function(id) {
    return Sleep.deleteById(id).catch(function(error) {
      console.error('Error deleting sleep data:', error);
      throw new Error('Error deleting sleep data');
    });
  }
};

// Function to convert ISO timestamp to IST using Luxon
function convertToIST(isoTimestamp) {
  const utcDateTime = DateTime.fromISO(isoTimestamp, { zone: 'utc' });
  const istDateTime = utcDateTime.setZone('Asia/Kolkata');
  return istDateTime.toFormat('dd/MM/yyyy, HH:mm:ss');
}

module.exports = sleepService;
