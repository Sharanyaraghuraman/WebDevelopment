const User = require('../models/userModel');

const userService = {
  registerUser: async (name, email, password) => {
    try {
      return await User.create(name, email, password);
    } catch (error) {
      console.error('Error registering user:', error);
      throw new Error('Error registering user');
    }
  },

  findUserByEmail: async (email) => {
    try {
      return await User.findByEmail(email);
    } catch (error) {
      console.error('Error finding user by email:', error);
      throw new Error('Error finding user by email');
    }
  }
};

module.exports = userService;
