const express = require('express');
const session = require('express-session');
const app = express();
const port = 3000;

// Middleware to serve static files from the public directory
app.use(express.static('public'));

// Middleware to parse incoming request bodies
app.use(express.urlencoded({ extended: true }));

// Session middleware
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true if using https
}));

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Routes
const indexRouter = require('./routes/index');
app.use('/', indexRouter);

// Start the server
app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});
