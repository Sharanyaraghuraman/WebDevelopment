const express = require('express');
const router = express.Router();
const sleepController = require('../controllers/sleepController');
const userController = require('../controllers/userController');

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
  if (req.session.userId) {
    return next();
  } else {
    res.redirect('/login');
  }
}

// Route to get all sleep data (protected)
router.get('/', isAuthenticated, sleepController.getAllSleepData);

// Route to add sleep data (protected)
router.post('/add', isAuthenticated, sleepController.addSleepData);

// Route to delete sleep data by ID (protected)
router.get('/delete/:id', isAuthenticated, sleepController.deleteSleepData);

// User registration and login routes
router.get('/register', userController.showRegister);
router.post('/register', userController.register);
router.get('/login', userController.showLogin);
router.post('/login', userController.login);
router.get('/logout', userController.logout);

module.exports = router;
