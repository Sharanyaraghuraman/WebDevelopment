// controllers/sleepController.js

const sleepService = require('../services/sleepService');

// Get all sleep data
exports.getAllSleepData = async (req, res) => {
  try {
    const sleepData = await sleepService.getAllSleepData();
    res.render('index', { sleepData });
  } catch (error) {
    console.error('Error fetching sleep data:', error);
    res.status(500).send('Error fetching sleep data');
  }
};

// Add new sleep data
exports.addSleepData = async (req, res) => {
  const { startTime, endTime, duration } = req.body;
  try {
    await sleepService.addSleepData(startTime, endTime, parseFloat(duration));
    res.redirect('/');
  } catch (error) {
    console.error('Error adding sleep data:', error);
    res.status(500).send('Error adding sleep data');
  }
};

// Delete sleep data by ID
exports.deleteSleepData = async (req, res) => {
  const { id } = req.params;
  try {
    await sleepService.deleteSleepDataById(id);
    res.redirect('/');
  } catch (error) {
    console.error('Error deleting sleep data:', error);
    res.status(500).send('Error deleting sleep data');
  }
};
