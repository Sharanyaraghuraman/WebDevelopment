document.addEventListener('DOMContentLoaded', () => {
  const startButton = document.getElementById('startButton');
  const stopButton = document.getElementById('stopButton');
  const sleepForm = document.getElementById('sleepForm');
  const startTimeInput = document.getElementById('startTime');
  const endTimeInput = document.getElementById('endTime');
  const durationInput = document.getElementById('duration');

  let startTime;

  startButton.addEventListener('click', () => {
    startTime = new Date();
    startButton.disabled = true;
    stopButton.disabled = false;
    startButton.classList.add('inactive');
    stopButton.classList.remove('inactive');
    startButton.textContent = 'Tracking Started';
  });

  stopButton.addEventListener('click', () => {
    const endTime = new Date();
    startTimeInput.value = startTime.toISOString();
    endTimeInput.value = endTime.toISOString();

    const durationMs = endTime - startTime;
    const durationHours = durationMs / (1000 * 60 * 60);
    durationInput.value = durationHours.toFixed(2);

    stopButton.disabled = true;
    startButton.disabled = false;
    startButton.classList.remove('inactive');
    stopButton.classList.add('inactive');
    startButton.textContent = 'Start';
    sleepForm.style.display = 'block';
  });
});
